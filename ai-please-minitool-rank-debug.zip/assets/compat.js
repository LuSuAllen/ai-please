(function(){try{
var de=document.documentElement;
var box=document.createElement('div');
box.style.cssText='position:absolute;top:-9999px;left:-9999px;display:flex;flex-direction:column;gap:1px;width:10px';
var a=document.createElement('div'),b=document.createElement('div');
a.style.height='1px';b.style.height='1px';
box.appendChild(a);box.appendChild(b);de.appendChild(box);
var h=box.getBoundingClientRect().height;
de.removeChild(box);
if(!(h>2.5)){de.className=de.className?de.className+' no-flex-gap':'no-flex-gap';}
}catch(e){}})();